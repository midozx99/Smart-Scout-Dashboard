from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import networkx as nx
import matplotlib.pyplot as plt
import time
import re
import os
import sys
import io
import webbrowser
import datetime
from matplotlib.lines import Line2D


# ═══════════════════════════════════════════════
#  SMART FILTER & HELPERS # mohammed  mohammed
# ═══════════════════════════════════════════════

def clean_price(price_str):
    # عملت الدالة دي عشان أنضف السعر من أي حروف أو فواصل وأخليه رقم صحيح أقدر أتعامل معاه
    try:
        match = re.search(r"[\d,]+(?:\.\d+)?", str(price_str))
        if match:
            return float(match.group(0).replace(",", ""))
    except Exception:
        pass  # بيسكب ال error
    return None


def is_relevant_product(product_name: str, search_term: str, price: float = None) -> bool:  # لازم يبقي استرنج
    # ده الفلتر اللي بنيته عشان أصطاد الإكسسوارات وأمنعها إنها تبوظلي داتا الأجهزة
    name_lower = product_name.lower()
    term_lower = search_term.lower()

    # جمعت هنا كل الكلمات اللي ممكن تدل على إن المنتج ده مجرد إكسسوار مش جهاز
    exclude_words = [
        "جراب", "سكرين", "كفر", "غطاء", "شاحن", "كابل", "وصلة", "حامي", "حماية", "لاصقة", "زجاج",
        "شنطة", "حقيبة", "ماوس", "كيبورد", "حزام", "استيك", "قاعدة", "حامل", "ستاند", "محول", "سلك",
        "واقي", "حافظة", "سيليكون", "متوافق",
        "case", "cover", "screen", "protector", "cable", "charger", "adapter", "glass",
        "bag", "mouse", "keyboard", "strap", "band", "stand", "holder", "ring", "film", "lens",
        "silicone", "tempered", "clear"
    ]

    is_searching_for_accessory = any(word in term_lower for word in exclude_words)

    if not is_searching_for_accessory:
        # 1. أول خطوة: بفلتر بناء على الكلمات اللي فوق
        for word in exclude_words:
            if word in name_lower:
                return False

        # 2. تاني خطوة: بفلتر بالسعر (ودي التريكاية بتاعتي عشان أمازون ميهيسش ويجيبلي جراب بـ 50 جنيه)
        main_devices = ["موبايل", "هاتف", "تليفون", "لاب", "لابتوب", "شاشة", "تلفزيون", "فون", "ايفون", "phone",
                        "laptop", "tv", "ساعة", "watch", "iphone", "samsung"]
        is_main_device = any(dev in term_lower for dev in main_devices)

        if is_main_device and price is not None:
            if price < 500:  # بديهي أي جهاز من دول تحت الـ 500 جنيه أكيد إكسسوار
                return False

    return True


def get_driver(headless=True):
    # هنا بجهز متصفح سيلينيوم وبحطله الخصائص بتاعته عشان يشتغل في الخلفية من غير ما يفتحلي ويدوشني
    options = Options()
    if headless:
        options.add_argument("--headless")
    options.add_argument("--disable-blink-features=AutomationControlled")  # AutomationControlled  لغيت ال
    options.add_argument("--no-sandbox")  # بلغي  نظام حمايه  كروم
    options.add_argument("--disable-dev-shm-usage")  # خليتو يستعمل مساحه الهارد بدل الرامات
    options.add_argument("window-size=1920,1080")  # بيفتح زى الكمبيوتر
    options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
    )  # اللهو الخفي
    return webdriver.Chrome(options=options)


def extract_brand(name: str, search_words: list) -> str:
    match = re.search(r'[A-Za-z]+', name)
    if match:
        brand = match.group(0).capitalize()  # بخلي شكل الكمله عدل عشان لو  مكتوبه  بشكل وحش
        if brand.lower() not in search_words and len(brand) > 1:
            return brand
    return "Other"


# ═══════════════════════════════════════════════
#  SCRAPER 1 — JUMIA (MAIN)  # mohammed  shalash
# ═══════════════════════════════════════════════

def scrape_jumia(search_term: str) -> list:
    print("\n[Jumia] Starting main scraping...")
    driver = get_driver(headless=True)
    results = []
    try:
        driver.get("https://www.jumia.com.eg/ar/")
        wait = WebDriverWait(driver, 20)
        # قفل الاعلانات
        try:
            close_btn = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button.cls")))
            close_btn.click()
        except Exception:
            pass

        search_box = wait.until(EC.presence_of_element_located((By.NAME, "q")))
        search_box.send_keys(search_term)
        search_box.send_keys(Keys.RETURN)
        wait.until(EC.presence_of_element_located((By.CLASS_NAME, "prd")))
        time.sleep(2)
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)

        soup = BeautifulSoup(driver.page_source, "html.parser")
        for article in soup.find_all("article", class_="prd"):
            name_el = article.find("h3", class_="name")
            price_el = article.find("div", class_="prc")
            link_el = article.find("a", href=True)
            if name_el and price_el:
                name = name_el.text.strip()
                price_val = clean_price(price_el.text.strip())
                # بطبق الفلتر بتاعي هنا عشان أتأكد إن المنتج يستاهل يتضاف
                if is_relevant_product(name, search_term, price_val):
                    results.append({
                        "name": name,
                        "price": price_val,
                        "link": "https://www.jumia.com.eg" + link_el["href"] if link_el else "",
                        "source": "Jumia",
                    })
        print(f"[Jumia] Found {len(results)} relevant products.")
    except Exception as e:
        print(f"[Jumia] Error: {e}")
    finally:
        driver.quit()
    return results


# ═══════════════════════════════════════════════
#  SCRAPER 2 — AMAZON (GENERAL)
# ═══════════════════════════════════════════════

def scrape_amazon(search_term: str) -> list:
    """سكريبر أمازون للبحث العام — بيجيب المنتجات من أمازون مصر عشان نقارنها مع جوميا"""
    print("\n[Amazon] Starting general scraping...")
    driver = get_driver(headless=True)
    results = []
    try:
        driver.get(f"https://www.amazon.eg/s?k={search_term.replace(' ', '+')}")
        time.sleep(3)
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)

        soup = BeautifulSoup(driver.page_source, "html.parser")
        for item in soup.select('[data-component-type="s-search-result"]'):
            n = item.select_one("h2 span")
            p = item.select_one(".a-price .a-offscreen")
            l = item.select_one("h2 a")
            if n and p:
                name = n.text.strip()
                price_val = clean_price(p.text)
                if not l:
                    l = item.select_one("a.a-link-normal")
                href = l["href"] if l and l.has_attr("href") else ""
                if href and not href.startswith("http"):
                    href = "https://www.amazon.eg" + href
                if is_relevant_product(name, search_term, price_val):
                    results.append({
                        "name": name,
                        "price": price_val,
                        "link": href,
                        "source": "Amazon",
                    })
        print(f"[Amazon] Found {len(results)} relevant products.")
    except Exception as e:
        print(f"[Amazon] Error: {e}")
    finally:
        driver.quit()
    return results


# ═══════════════════════════════════════════════
#  DATA PROCESSING # mohammed shalash
# ═══════════════════════════════════════════════

def process(products: list, search_term: str) -> pd.DataFrame:
    df = pd.DataFrame(products)
    if df.empty:
        return df
    search_words = search_term.lower().split()
    df.dropna(subset=["price"], inplace=True)
    df.drop_duplicates(subset=["name"], inplace=True)
    df = df[df["price"] > 0].copy()

    df["brand"] = df["name"].apply(lambda n: extract_brand(n, search_words))
    q33, q66 = df["price"].quantile(0.33), df["price"].quantile(0.66)
    df["price_category"] = df["price"].apply(
        lambda p: "Low" if p <= q33 else ("Medium" if p <= q66 else "High")
    )
    print(f"[Processing] {len(df)} products ready for analysis.")
    return df.reset_index(drop=True)


# ═══════════════════════════════════════════════
#  DEEP SEARCH (AMAZON & JUMIA ONLY) #mohammed  mohammed
# ═══════════════════════════════════════════════

def deep_search(product_name: str, brand: str = "") -> dict:
    print(f"\n[Deep Search] Searching directly for: {product_name} {brand}...")
    query = f"{brand} {product_name}".strip()
    result = {"amazon": [], "jumia": [], "official_site": "", "reviews_url": ""}

    driver = get_driver(headless=True)

    # ده الكود اللي بيعمل السيرش العميق في أمازون عشان يجيب أسعار دقيقة
    try:
        driver.get(f"https://www.amazon.eg/s?k={query.replace(' ', '+')}")
        time.sleep(3)
        soup = BeautifulSoup(driver.page_source, "html.parser")
        for item in soup.select('[data-component-type="s-search-result"]'):
            n = item.select_one("h2 span")
            p = item.select_one(".a-price .a-offscreen")
            l = item.select_one("h2 a")
            if n and p:
                name = n.text.strip()
                price_val = clean_price(p.text)  # بيقرء التكست  كلو  و يرجع البريس بس
                if not l:
                    l = item.select_one("a.a-link-normal")  # دي حركة احتياطية عشان لو أمازون غيرت اسم الكلاس (Class)

                href = l["href"] if l and l.has_attr("href") else ""
                if href and not href.startswith("http"):
                    href = "https://www.amazon.eg" + href

                if is_relevant_product(name, query, price_val):
                    result["amazon"].append({
                        "name": name,
                        "price": price_val,
                        "link": href,
                        "source": "Amazon"
                    })
            if len(result["amazon"]) >= 6: break
    except Exception:
        pass

    # ونفس الكلام بعمله هنا، سيرش عميق في جوميا
    try:
        driver.get(f"https://www.jumia.com.eg/ar/catalog/?q={query.replace(' ', '+')}")
        time.sleep(3)
        soup = BeautifulSoup(driver.page_source, "html.parser")
        for article in soup.find_all("article", class_="prd"):
            n = article.find("h3", class_="name")
            p = article.find("div", class_="prc")
            l = article.find("a", href=True)
            if n and p:
                name = n.text.strip()
                price_val = clean_price(p.text.strip())

                href = l["href"] if l and l.has_attr("href") else ""
                if href and not href.startswith("http"):
                    href = "https://www.jumia.com.eg" + href

                if is_relevant_product(name, query, price_val):
                    result["jumia"].append({
                        "name": name,
                        "price": price_val,
                        "link": href,
                        "source": "Jumia"
                    })
            if len(result["jumia"]) >= 6: break
    except Exception:
        pass

    driver.quit()

    if brand and brand.lower() not in ("other", ""):
        result["official_site"] = f"https://www.{brand.lower().replace(' ', '')}.com"
    result["reviews_url"] = f"https://www.google.com/search?q={query.replace(' ', '+')}+reviews"
    return result, query


# ═══════════════════════════════════════════════
#  PRO REPORT & SUMMARY GENERATOR #  mohammed  shalash
# ═══════════════════════════════════════════════

def save_and_print_deep_results(data: dict, query: str):
    # عملت الدالة دي عشان تحفظلي الريبورت في تكست فايل، وكمان تطبعلي ملخص سريع في الكونسول
    filename = f"{query.replace(' ', '_')}_Market_Report.txt"
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = []
    lines.append("=" * 70)
    lines.append(f"{'DEEP SEARCH MARKET REPORT':^70}")
    lines.append("=" * 70)
    lines.append(f"Search Query : {query}")
    lines.append(f"Date         : {now}")
    lines.append("-" * 70)

    for source_name, key in [("Amazon Egypt", "amazon"), ("Jumia Egypt", "jumia")]:
        lines.append(f"\n[ {source_name.upper()} ]")
        lines.append("-" * 70)
        if data[key]:
            for i, item in enumerate(data[key], 1):
                p = f"{int(item['price']):,} EGP" if item["price"] else "N/A"
                lines.append(f" {i}. {item['name']}")
                lines.append(f"    Price: {p}")
                lines.append(f"    Link : {item['link']}")
        else:
            lines.append("    No matching results found.")

    all_prices = []
    for src in ["amazon", "jumia"]:
        for item in data[src]:
            if item["price"]:
                all_prices.append((item["price"], src.capitalize(), item["name"]))

    cheapest = most_expensive = None
    if all_prices:
        cheapest = min(all_prices, key=lambda x: x[0])
        most_expensive = max(all_prices, key=lambda x: x[0])
        lines.append("\n*** BEST DEALS ***")
        lines.append(f"   Cheapest: {int(cheapest[0]):,} EGP at {cheapest[1]}")
        lines.append(f"   Product : {cheapest[2]}")

    with open(filename, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"[Deep Search] Data saved to file: {filename}")

    # هنا بطبع الملخص بتاعي على الكونسول عشان أشوف النتيجة بسرعة
    print("\n" + "=" * 40)
    print(f"{'DEEP SEARCH SUMMARY':^40}")
    print("=" * 40)
    print(f" Amazon Results : {len(data['amazon'])} items")
    print(f" Jumia Results  : {len(data['jumia'])} items")
    print("-" * 40)
    if cheapest and most_expensive:
        print(f" Cheapest Store : {cheapest[1]} ({int(cheapest[0]):,} EGP)")
        print(f" Most Expensive : {most_expensive[1]} ({int(most_expensive[0]):,} EGP)")
    else:
        print(" No valid prices found for summary.")
    print("=" * 40)


# ═══════════════════════════════════════════════
#  YOUR EXACT CUSTOM NETWORKX GRAPH LOGIC # mohammed  mohammed
# ═══════════════════════════════════════════════

def no_overlap_layout(G, root):
    # دي الخوارزمية اللي أنا عملتها عشان أوزع بيها النقط ومفيش حاجة تركب على التانية (Tree Layout)
    try:
        from networkx.drawing.nx_agraph import graphviz_layout
        return graphviz_layout(G, prog='dot')  # عشان يبني شكل الشجره
    except ImportError:
        # لو مكتبة graphviz مش متسطبة عندي، دي الطريقة البديلة اللي بستخدمها عشان أرسم الشجرة
        pos = {}
        pos[root] = (0.5, 1.0)  # برفع الـ Root فوق خالص عشان يبقى على رأس الشجرة

        brands = list(G.successors(root))
        if not brands: return pos

        for i, brand in enumerate(brands):
            # بوزع البراندات في خط النص بالظبط و بتساوى
            bx = (i + 1.0) / (len(brands) + 1.0)
            pos[brand] = (bx, 0.5)

            # وبوزع الفئات تحت كل براند لوحده
            cats = list(G.successors(brand))
            if cats:
                spacing = 0.8 / (len(brands) * max(3, len(cats)))
                for j, cat in enumerate(cats):
                    cx = bx + (j - (len(cats) - 1) / 2.0) * spacing
                    pos[cat] = (cx, 0.0)  # بنزل الفئات تحت خالص في قاع الرسمة
        return pos


def build_custom_graph(df, search_term):
    # بجهز الداتا بتاعتي هنا عشان تركب على كود الرسم بتاعي
    G = nx.DiGraph()  # خليتها DiGraph عشان تترسم كشجرة (خطوط ليها اتجاه)
    root = "Market"
    G.add_node(root, type="root", level=0)

    for brand in df["brand"].unique():
        if brand.lower() == "other": continue  # شلت الـ Other عشان أنضف الرسمة ومتبقاش زحمة
        G.add_node(brand, type="brand", level=1)
        G.add_edge(root, brand)

        bdf = df[df["brand"] == brand]
        for cat in ["Low", "Medium", "High"]:
            cdf = bdf[bdf["price_category"] == cat]
            if not cdf.empty:
                node_name = f"{brand}_{cat}"
                label = f"{cat}\n({len(cdf)} items)"  # Medium (4 items)
                G.add_node(node_name, type="category", category=cat, label=label, level=2)
                G.add_edge(brand, node_name)
    return G, root


def draw_graph(G, root, df, search_term):
    print("\n[NetworkX] Building your custom market tree graph...")

    # avg price
    low_avg = df[df["price_category"] == "Low"]["price"].mean()
    mid_avg = df[df["price_category"] == "Medium"]["price"].mean()
    high_avg = df[df["price_category"] == "High"]["price"].mean()

    stats_text = (f"Average Prices:\n"
                  f"Low: {int(low_avg or 0):,} EGP\n"
                  f"Mid: {int(mid_avg or 0):,} EGP\n"
                  f"High: {int(high_avg or 0):,} EGP")
    # -------------------------------------------------------

    pos = no_overlap_layout(G, root)

    # #22c55e: لون أخضر فاتح للفئة الرخيصة
    # #3b82f6: لون أزرق للفئة المتوسطة
    # #f97316: لون برتقالي للفئة الغالية
    cat_color = {"Low": "#22c55e", "Medium": "#3b82f6", "High": "#f97316"}
    color_map = []
    node_sizes = []

    for node, d in G.nodes(data=True):
        t = d.get("type")
        if t == "root":
            color_map.append("#e2e8f0")  # #e2e8f0: رصاصي فاتح مدي لـ أبيض (لون الـ Market Root)
            node_sizes.append(4000)
        elif t == "brand":
            color_map.append("#ef4444")  # #ef4444: لون أحمر (لون دوائر البراندات)
            node_sizes.append(3000)
        else:
            color_map.append(cat_color[d["category"]])
            node_sizes.append(2500)

    fig, ax = plt.subplots(figsize=(20, 10))
    ax.set_facecolor("#0f172a")  # #0f172a: لون كحلي غامق (لون خلفية منطقة الرسم)
    fig.patch.set_facecolor("#0f172a")  # #0f172a: لون كحلي غامق (لون إطار الصورة من بره)

    nx.draw_networkx_nodes(G, pos, node_color=color_map, node_size=node_sizes, ax=ax)

    # #334155: لون رصاصي غامق للخطوط اللي موصلة بين الدوائر
    nx.draw_networkx_edges(G, pos, edge_color="#334155", ax=ax, arrows=False)  # شلت الأسهم عشان تطلع زي الديزاين بتاعي

    labels = {}
    for node, d in G.nodes(data=True):
        if d.get("type") == "category":
            labels[node] = d["label"]
        else:
            labels[node] = node

    # font_color="white": خط أبيض للكتابة اللي جوه الدوائر
    nx.draw_networkx_labels(G, pos, labels=labels, font_size=9, font_color="white", ax=ax)

# مكان بوكس ال avg
    plt.text(0.05, 0.95, stats_text, transform=ax.transAxes, color="white",
             fontsize=12, bbox=dict(facecolor='#1e293b', alpha=0.8), ha='left', va='top')

    # color="white": خط أبيض لعنوان الرسمة من فوق
    ax.set_title(f"{search_term.capitalize()} Market — Market → Brand → Category (Number of Items)", color="white",
                 fontsize=14)
    ax.axis("off")

    plt.tight_layout()
    output_img = f"{search_term}_market_tree.png"
    plt.savefig(output_img, dpi=150, facecolor=fig.get_facecolor())
    plt.close()
    print(f"[NetworkX] Graph saved as: {output_img}")
    return output_img



# ═══════════════════════════════════════════════
#  COMPETITIVE MARKET NETWORK ANALYSIS
# ═══════════════════════════════════════════════

def build_competitive_network(df, search_term, price_threshold=0.15):
    """
    بنيت الفانكشن دي عشان تبني شبكة تنافسية للسوق:
    - الشركات كـ Nodes
    - الموبايلات كـ Nodes
    - ربط كل شركة بموبايلاتها (Ownership Edge)
    - ربط الموبايلات القريبة في السعر من شركات مختلفة (Competition Edge)
    """
    G = nx.Graph()

    # ─── إضافة الشركات كـ Nodes ───
    for brand in df["brand"].unique():
        if brand.lower() == "other":
            continue
        product_count = len(df[df["brand"] == brand])
        avg_price = df[df["brand"] == brand]["price"].mean()
        G.add_node(brand, type="company", label=brand,
                   product_count=product_count, avg_price=avg_price)

    # ─── إضافة الموبايلات و ربطها بالشركات ───
    for idx, row in df.iterrows():
        if row["brand"].lower() == "other":
            continue
        phone_id = f"P{idx}"
        short_name = row["name"][:45]
        G.add_node(phone_id, type="phone", label=short_name,
                   price=row["price"], brand=row["brand"],
                   price_category=row["price_category"],
                   full_name=row["name"])
        G.add_edge(row["brand"], phone_id, type="ownership", weight=1.0)

    # ─── ربط الموبايلات المتنافسة (أسعار قريبة من شركات مختلفة) ───
    phone_nodes = [(n, d) for n, d in G.nodes(data=True) if d.get("type") == "phone"]
    competition_count = 0
    for i in range(len(phone_nodes)):
        for j in range(i + 1, len(phone_nodes)):
            n1, d1 = phone_nodes[i]
            n2, d2 = phone_nodes[j]
            if d1["brand"] == d2["brand"]:
                continue
            p1, p2 = d1["price"], d2["price"]
            avg_price = (p1 + p2) / 2
            if avg_price > 0:
                diff_ratio = abs(p1 - p2) / avg_price
                if diff_ratio <= price_threshold:
                    similarity = round(1.0 - diff_ratio, 3)
                    G.add_edge(n1, n2, type="competition",
                               weight=similarity,
                               price_diff=round(abs(p1 - p2), 2))
                    competition_count += 1

    print(f"[Network] Built competitive network: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    print(f"[Network] Competition edges: {competition_count}")
    return G


def analyze_network(G):
    """تحليل شامل للشبكة التنافسية"""
    analysis = {}
    if G.number_of_nodes() == 0:
        return analysis

    # ─── Centrality Metrics ───
    analysis["degree"] = nx.degree_centrality(G)
    analysis["betweenness"] = nx.betweenness_centrality(G, weight="weight")
    analysis["load"] = nx.load_centrality(G, weight="weight")
    analysis["pagerank"] = nx.pagerank(G, weight="weight", max_iter=200)

    # ─── Community Detection ───
    try:
        from networkx.algorithms.community import greedy_modularity_communities
        communities = list(greedy_modularity_communities(G, weight="weight"))
        analysis["communities"] = communities
    except Exception:
        analysis["communities"] = []

    # ─── Key Node Identification ───
    analysis["most_connected"] = max(analysis["degree"], key=analysis["degree"].get)
    analysis["highest_traffic"] = max(analysis["betweenness"], key=analysis["betweenness"].get)
    analysis["most_influential"] = max(analysis["pagerank"], key=analysis["pagerank"].get)

    # ─── Competition Analysis ───
    comp_edges = [(u, v, d) for u, v, d in G.edges(data=True) if d.get("type") == "competition"]
    analysis["competition_edges"] = sorted(comp_edges, key=lambda x: x[2].get("weight", 0), reverse=True)

    # ─── Company-Level Metrics ───
    company_nodes = [n for n, d in G.nodes(data=True) if d.get("type") == "company"]
    if company_nodes:
        analysis["company_pagerank"] = {n: analysis["pagerank"].get(n, 0) for n in company_nodes}
        analysis["company_degree"] = {n: analysis["degree"].get(n, 0) for n in company_nodes}
        analysis["company_betweenness"] = {n: analysis["betweenness"].get(n, 0) for n in company_nodes}
        analysis["most_influential_company"] = max(
            analysis["company_pagerank"], key=analysis["company_pagerank"].get)
    else:
        analysis["most_influential_company"] = None

    # ─── Price Range Dominance ───
    price_dominance = {"Low": {}, "Medium": {}, "High": {}}
    for n, d in G.nodes(data=True):
        if d.get("type") == "phone":
            cat = d.get("price_category", "")
            brand = d.get("brand", "")
            if cat in price_dominance:
                price_dominance[cat][brand] = price_dominance[cat].get(brand, 0) + 1
    analysis["price_dominance"] = price_dominance

    return analysis


def generate_network_report(G, analysis, search_term):
    """توليد تقرير تحليل الشبكة التنافسية كنص"""
    lines = []

    def get_label(node):
        return G.nodes[node].get("label", str(node))

    lines.append("═" * 60)
    lines.append(f"{'COMPETITIVE MARKET NETWORK ANALYSIS':^60}")
    lines.append(f"{'Search: ' + search_term:^60}")
    lines.append("═" * 60)

    companies = [n for n, d in G.nodes(data=True) if d.get("type") == "company"]
    phones = [n for n, d in G.nodes(data=True) if d.get("type") == "phone"]
    own_edges = sum(1 for _, _, d in G.edges(data=True) if d.get("type") == "ownership")
    comp_edges_count = sum(1 for _, _, d in G.edges(data=True) if d.get("type") == "competition")

    lines.append(f"\nNetwork Overview:")
    lines.append(f"   Total Nodes       : {G.number_of_nodes()}")
    lines.append(f"   Total Edges       : {G.number_of_edges()}")
    lines.append(f"   Companies         : {len(companies)}")
    lines.append(f"   Phone Models      : {len(phones)}")
    lines.append(f"   Ownership Edges   : {own_edges}")
    lines.append(f"   Competition Edges : {comp_edges_count}")

    # ─── Key Players ───
    #هنا  اهم الشركات  و المنتجات  و كل دا يعني
    lines.append(f"\nKey Players:")
    mc = analysis.get("most_connected")
    if mc:
        lines.append(f"   Most Connected Node : {get_label(mc)} (Degree: {analysis['degree'][mc]:.4f})")
    ht = analysis.get("highest_traffic")
    if ht:
        lines.append(f"   Highest Traffic Node: {get_label(ht)} (Betweenness: {analysis['betweenness'][ht]:.4f})")
    mi = analysis.get("most_influential")
    if mi:
        lines.append(f"   Most Influential    : {get_label(mi)} (PageRank: {analysis['pagerank'][mi]:.4f})")
    mic = analysis.get("most_influential_company")
    if mic:
        lines.append(f"   Top Company         : {mic} (PageRank: {analysis['company_pagerank'][mic]:.4f})")

    # ─── Company Rankings ───
    if analysis.get("company_pagerank"):
        lines.append(f"\nCompany Rankings (by PageRank):")
        sorted_companies = sorted(analysis["company_pagerank"].items(), key=lambda x: x[1], reverse=True)
        for i, (comp, pr) in enumerate(sorted_companies[:10], 1):
            deg = analysis["company_degree"].get(comp, 0)
            betw = analysis["company_betweenness"].get(comp, 0)
            load_val = analysis["load"].get(comp, 0)
            lines.append(
                f"   {i}. {comp:20s} | PageRank: {pr:.4f} | Degree: {deg:.4f}"
                f" | Betweenness: {betw:.4f} | Load: {load_val:.4f}")

    # ─── Top Competing Pairs ───
    comp_list = analysis.get("competition_edges", [])
    if comp_list:
        lines.append(f"\nTop Competing Phone Pairs (by price similarity):")
        for u, v, d in comp_list[:10]:
            l1, l2 = get_label(u), get_label(v)
            p1 = G.nodes[u].get("price", 0)
            p2 = G.nodes[v].get("price", 0)
            diff = d.get("price_diff", 0)
            sim = d.get("weight", 0)
            lines.append(f"   * {l1[:35]:35s} ({int(p1):,} EGP)")
            lines.append(f"     vs {l2[:35]:35s} ({int(p2):,} EGP)")
            lines.append(f"     Similarity: {sim:.1%} | Price Diff: {int(diff):,} EGP")

    # ─── Communities ───
    communities = analysis.get("communities", [])
    if communities:
        lines.append(f"\nMarket Communities Detected: {len(communities)}")
        for i, comm in enumerate(communities[:5], 1):
            comm_companies = [n for n in comm if G.nodes[n].get("type") == "company"]
            comm_phones = [n for n in comm if G.nodes[n].get("type") == "phone"]
            lines.append(
                f"   Community {i}: {len(comm)} members"
                f" ({len(comm_companies)} companies, {len(comm_phones)} phones)")
            if comm_companies:
                lines.append(f"     Companies: {', '.join(comm_companies[:5])}")

    # ─── Price Range Dominance ───
    pd_data = analysis.get("price_dominance", {})
    if pd_data:
        lines.append(f"\nPrice Range Dominance:")
        for cat in ["Low", "Medium", "High"]:
            brands = pd_data.get(cat, {})
            if brands:
                dominant = max(brands, key=brands.get)
                lines.append(f"   {cat:8s}: {dominant} ({brands[dominant]} phones)")

    lines.append("\n" + "═" * 60)
    return "\n".join(lines)


def print_network_report(G, analysis, search_term):
    """طباعة التقرير على الكونسول"""
    report = generate_network_report(G, analysis, search_term)
    print(report)


def save_network_report(G, analysis, search_term):
    """حفظ التقرير في ملف نصي"""
    report = generate_network_report(G, analysis, search_term)
    filename = f"{search_term}_competitive_network_report.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(report)
    print(f"[Network] Report saved: {filename}")
    return filename


def draw_competitive_network(G, analysis, search_term):
    """رسم الشبكة التنافسية بتصميم Force-Directed Layout"""
    #بعامل  النود انها  سوسته  او  مغناطيس  فا مفيش  نود بتلمس  التانيه
    print("\n[Network] Drawing competitive market network...")
    if G.number_of_nodes() == 0:
        print("[Network] Empty graph, skipping.")
        return None

    fig, ax = plt.subplots(figsize=(22, 14))
    ax.set_facecolor("#0f172a")
    fig.patch.set_facecolor("#0f172a")

    # ─── Force-Directed Layout ───
    pos = nx.spring_layout(G, k=2.5, iterations=80, weight="weight", seed=42)

    # ─── Prepare data ───
    pagerank = analysis.get("pagerank", {})
    max_pr = max(pagerank.values()) if pagerank else 1
    company_nodes = [n for n, d in G.nodes(data=True) if d.get("type") == "company"]
    phone_nodes = [n for n, d in G.nodes(data=True) if d.get("type") == "phone"]
    cat_colors = {"Low": "#22c55e", "Medium": "#3b82f6", "High": "#f97316"}

    # ─── Draw Ownership Edges (gray, solid) ───
    own_edges = [(u, v) for u, v, d in G.edges(data=True) if d.get("type") == "ownership"]
    if own_edges:
        nx.draw_networkx_edges(G, pos, edgelist=own_edges,
                               edge_color="#475569", width=1.5, alpha=0.6, ax=ax)

    # ─── Draw Competition Edges (red, dashed) ───
    comp_edges = [(u, v) for u, v, d in G.edges(data=True) if d.get("type") == "competition"]
    if comp_edges:
        comp_widths = [G[u][v].get("weight", 0.5) * 2.5 for u, v in comp_edges]
        nx.draw_networkx_edges(G, pos, edgelist=comp_edges,
                               edge_color="#ef4444", width=comp_widths,
                               alpha=0.35, style="dashed", ax=ax)

    # ─── Draw Company Nodes (gold, large) ───
    if company_nodes:
        c_sizes = [2000 + (pagerank.get(n, 0) / max_pr) * 4000 for n in company_nodes]
        nx.draw_networkx_nodes(G, pos, nodelist=company_nodes,
                               node_color="#f59e0b", node_size=c_sizes,
                               edgecolors="#fbbf24", linewidths=2.5, alpha=0.95, ax=ax)

    # ─── Draw Phone Nodes (colored by price category) ───
    if phone_nodes:
        p_colors = [cat_colors.get(G.nodes[n].get("price_category", "Medium"), "#3b82f6")
                    for n in phone_nodes]
        p_sizes = [600 + (pagerank.get(n, 0) / max_pr) * 2500 for n in phone_nodes]
        nx.draw_networkx_nodes(G, pos, nodelist=phone_nodes,
                               node_color=p_colors, node_size=p_sizes,
                               edgecolors="white", linewidths=0.8, alpha=0.85, ax=ax)

    # ─── Company Labels (always shown, bold) ───
    company_labels = {n: n for n in company_nodes}
    nx.draw_networkx_labels(G, pos, labels=company_labels,
                            font_size=11, font_weight="bold", font_color="white", ax=ax)

    # ─── Phone Labels (top 15 by PageRank only, to avoid clutter) ───
    top_phones = sorted(phone_nodes, key=lambda n: pagerank.get(n, 0), reverse=True)
    phone_labels = {}
    for n in top_phones[:15]:
        label = G.nodes[n].get("label", "")
        price = G.nodes[n].get("price", 0)
        phone_labels[n] = f"{label[:20]}\n{int(price):,}"
    nx.draw_networkx_labels(G, pos, labels=phone_labels,
                            font_size=7, font_color="#e2e8f0", ax=ax)

    # ─── Legend ───
    #هنا كل  لون معنه ايه  مستعمل  اخضر و  دهبي  برتقالي و  ازرق الخط الرمادي مبين الشركات  و  الاحمر  ل  الموبيلات
    legend_elements = [
        Line2D([0], [0], marker='o', color='w', markerfacecolor='#f59e0b',
               markersize=14, label='Company', linestyle='None'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor='#22c55e',
               markersize=10, label='Low Price Phone', linestyle='None'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor='#3b82f6',
               markersize=10, label='Medium Price Phone', linestyle='None'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor='#f97316',
               markersize=10, label='High Price Phone', linestyle='None'),
        Line2D([0], [0], color='#475569', linewidth=2, label='Ownership'),
        Line2D([0], [0], color='#ef4444', linewidth=2, linestyle='--', label='Competition'),
    ]
    ax.legend(handles=legend_elements, loc='upper left',
             facecolor='#1e293b', edgecolor='#334155',
             fontsize=10, labelcolor='white')

    # ─── Stats Box ───
    mic = analysis.get("most_influential_company", "N/A")
    mc = analysis.get("most_connected")
    mc_label = get_label_safe(G, mc) if mc else "N/A"
    communities = analysis.get("communities", [])
    n_comp = sum(1 for _, _, d in G.edges(data=True) if d.get("type") == "competition")
    stats_text = (
        f"Nodes: {G.number_of_nodes()} | Edges: {G.number_of_edges()}\n"
        f"Top Company: {mic}\n"
        f"Most Connected: {mc_label[:25]}\n"
        f"Communities: {len(communities)}\n"
        f"Competition Links: {n_comp}"
    )
    ax.text(0.98, 0.98, stats_text, transform=ax.transAxes, color="white",
            fontsize=10, ha='right', va='top',
            bbox=dict(facecolor='#1e293b', alpha=0.85,
                      edgecolor='#334155', boxstyle='round,pad=0.5'))

    ax.set_title(
        f"{search_term.capitalize()} — Competitive Market Network Analysis",
        color="white", fontsize=16, fontweight="bold", pad=20)
    ax.axis("off")

    plt.tight_layout()
    output_file = f"{search_term}_competitive_network.png"
    plt.savefig(output_file, dpi=180, facecolor=fig.get_facecolor(), bbox_inches='tight')
    plt.close()
    print(f"[Network] Competitive network saved: {output_file}")
    return output_file


def get_label_safe(G, node):
    """Helper: بيرجع الـ label بتاع أي node بأمان"""
    if node and node in G.nodes:
        return G.nodes[node].get("label", str(node))
    return str(node)


# ═══════════════════════════════════════════════
#  MARKET HEATMAP ANALYSIS SYSTEM
# ═══════════════════════════════════════════════

def build_brand_competition_matrix(G):
    """بيبني ماتريكس المنافسة بين البراندات بناءً على الـ competition edges"""
    companies = sorted([n for n, d in G.nodes(data=True) if d.get("type") == "company"])
    if not companies:
        return None, []
    size = len(companies)
    matrix = np.zeros((size, size))
    brand_idx = {b: i for i, b in enumerate(companies)}

    for u, v, d in G.edges(data=True):
        if d.get("type") != "competition":
            continue
        b1 = G.nodes[u].get("brand", "")
        b2 = G.nodes[v].get("brand", "")
        if b1 in brand_idx and b2 in brand_idx:
            i, j = brand_idx[b1], brand_idx[b2]
            weight = d.get("weight", 1.0)
            matrix[i][j] += weight
            matrix[j][i] += weight

    return matrix, companies


def build_centrality_matrix(G, analysis):
    """بيبني ماتريكس الـ Centrality Metrics للشركات"""
    companies = sorted([n for n, d in G.nodes(data=True) if d.get("type") == "company"])
    if not companies:
        return None, [], []
    metrics = ["Degree", "Betweenness", "Load", "PageRank"]
    matrix = np.zeros((len(companies), len(metrics)))

    for i, comp in enumerate(companies):
        matrix[i][0] = analysis.get("degree", {}).get(comp, 0)
        matrix[i][1] = analysis.get("betweenness", {}).get(comp, 0)
        matrix[i][2] = analysis.get("load", {}).get(comp, 0)
        matrix[i][3] = analysis.get("pagerank", {}).get(comp, 0)

    return matrix, companies, metrics


def build_price_density_matrix(G):
    """بيبني ماتريكس كثافة المنتجات لكل براند في كل فئة سعرية"""
    companies = sorted([n for n, d in G.nodes(data=True) if d.get("type") == "company"])
    categories = ["Low", "Medium", "High"]
    if not companies:
        return None, [], []
    matrix = np.zeros((len(companies), len(categories)))
    brand_idx = {b: i for i, b in enumerate(companies)}

    for n, d in G.nodes(data=True):
        if d.get("type") == "phone":
            brand = d.get("brand", "")
            cat = d.get("price_category", "")
            if brand in brand_idx and cat in categories:
                matrix[brand_idx[brand]][categories.index(cat)] += 1

    return matrix, companies, categories


def build_node_influence_matrix(G, analysis):
    """بيبني ماتريكس تأثير أعلى 15 node في الشبكة"""
    pagerank = analysis.get("pagerank", {})
    if not pagerank:
        return None, [], []
    top_nodes = sorted(pagerank, key=pagerank.get, reverse=True)[:15]
    metrics = ["Degree", "Betweenness", "Load", "PageRank"]
    matrix = np.zeros((len(top_nodes), len(metrics)))
    labels = []

    for i, node in enumerate(top_nodes):
        lbl = G.nodes[node].get("label", str(node))
        labels.append(lbl[:25])
        matrix[i][0] = analysis.get("degree", {}).get(node, 0)
        matrix[i][1] = analysis.get("betweenness", {}).get(node, 0)
        matrix[i][2] = analysis.get("load", {}).get(node, 0)
        matrix[i][3] = pagerank.get(node, 0)

    return matrix, labels, metrics


def draw_heatmaps(G, analysis, search_term):
    """رسم 4 هيت مابات في صورة واحدة """
    print("\n[Heatmap] Building Market Heatmaps...")

    comp_matrix, comp_labels = build_brand_competition_matrix(G)
    cent_matrix, cent_rows, cent_cols = build_centrality_matrix(G, analysis)
    price_matrix, price_rows, price_cols = build_price_density_matrix(G)
    infl_matrix, infl_rows, infl_cols = build_node_influence_matrix(G, analysis)

    fig, axes = plt.subplots(2, 2, figsize=(24, 18))
    fig.patch.set_facecolor("#0f172a")
    fig.suptitle(
        f"{search_term.capitalize()} — Market Intelligence Heatmaps",
        color="white", fontsize=18, fontweight="bold", y=0.98)

    # ─── 1. Brand Competition Heatmap ───
    ax1 = axes[0][0]
    ax1.set_facecolor("#0f172a")
    if comp_matrix is not None and comp_matrix.size > 0:
        im1 = ax1.imshow(comp_matrix, cmap="YlOrRd", aspect="auto")
        ax1.set_xticks(range(len(comp_labels)))
        ax1.set_yticks(range(len(comp_labels)))
        ax1.set_xticklabels(comp_labels, rotation=45, ha="right", fontsize=8, color="white")
        ax1.set_yticklabels(comp_labels, fontsize=8, color="white")
        for i in range(len(comp_labels)):
            for j in range(len(comp_labels)):
                val = comp_matrix[i][j]
                if val > 0:
                    ax1.text(j, i, f"{val:.1f}", ha="center", va="center",
                             fontsize=7, color="black" if val > comp_matrix.max() * 0.6 else "white")
        cb1 = fig.colorbar(im1, ax=ax1, shrink=0.8)
        cb1.ax.yaxis.set_tick_params(color="white")
        cb1.outline.set_edgecolor("#334155")
        plt.setp(plt.getp(cb1.ax.axes, 'yticklabels'), color="white")
    ax1.set_title("Brand Competition Intensity", color="#f59e0b", fontsize=13, fontweight="bold", pad=10)
    ax1.tick_params(colors="white")

    # ─── 2. Centrality Metrics Heatmap ───
    ax2 = axes[0][1]
    ax2.set_facecolor("#0f172a")
    if cent_matrix is not None and cent_matrix.size > 0:
        im2 = ax2.imshow(cent_matrix, cmap="viridis", aspect="auto")
        ax2.set_xticks(range(len(cent_cols)))
        ax2.set_yticks(range(len(cent_rows)))
        ax2.set_xticklabels(cent_cols, fontsize=9, color="white")
        ax2.set_yticklabels(cent_rows, fontsize=8, color="white")
        for i in range(len(cent_rows)):
            for j in range(len(cent_cols)):
                ax2.text(j, i, f"{cent_matrix[i][j]:.3f}", ha="center", va="center",
                         fontsize=7, color="white")
        cb2 = fig.colorbar(im2, ax=ax2, shrink=0.8)
        cb2.ax.yaxis.set_tick_params(color="white")
        cb2.outline.set_edgecolor("#334155")
        plt.setp(plt.getp(cb2.ax.axes, 'yticklabels'), color="white")
    ax2.set_title("Company Centrality Metrics", color="#3b82f6", fontsize=13, fontweight="bold", pad=10)
    ax2.tick_params(colors="white")

    # ─── 3. Price Range Density Heatmap ───
    ax3 = axes[1][0]
    ax3.set_facecolor("#0f172a")
    if price_matrix is not None and price_matrix.size > 0:
        im3 = ax3.imshow(price_matrix, cmap="RdYlGn", aspect="auto")
        ax3.set_xticks(range(len(price_cols)))
        ax3.set_yticks(range(len(price_rows)))
        ax3.set_xticklabels(price_cols, fontsize=10, color="white")
        ax3.set_yticklabels(price_rows, fontsize=8, color="white")
        for i in range(len(price_rows)):
            for j in range(len(price_cols)):
                val = int(price_matrix[i][j])
                if val > 0:
                    ax3.text(j, i, str(val), ha="center", va="center",
                             fontsize=10, fontweight="bold",
                             color="black" if val > price_matrix.max() * 0.5 else "white")
        cb3 = fig.colorbar(im3, ax=ax3, shrink=0.8)
        cb3.ax.yaxis.set_tick_params(color="white")
        cb3.outline.set_edgecolor("#334155")
        plt.setp(plt.getp(cb3.ax.axes, 'yticklabels'), color="white")
    ax3.set_title("Price Range × Brand Density", color="#22c55e", fontsize=13, fontweight="bold", pad=10)
    ax3.tick_params(colors="white")

    # ─── 4. Node Influence Heatmap ───
    ax4 = axes[1][1]
    ax4.set_facecolor("#0f172a")
    if infl_matrix is not None and infl_matrix.size > 0:
        im4 = ax4.imshow(infl_matrix, cmap="magma", aspect="auto")
        ax4.set_xticks(range(len(infl_cols)))
        ax4.set_yticks(range(len(infl_rows)))
        ax4.set_xticklabels(infl_cols, fontsize=9, color="white")
        ax4.set_yticklabels(infl_rows, fontsize=7, color="white")
        for i in range(len(infl_rows)):
            for j in range(len(infl_cols)):
                ax4.text(j, i, f"{infl_matrix[i][j]:.3f}", ha="center", va="center",
                         fontsize=7, color="white")
        cb4 = fig.colorbar(im4, ax=ax4, shrink=0.8)
        cb4.ax.yaxis.set_tick_params(color="white")
        cb4.outline.set_edgecolor("#334155")
        plt.setp(plt.getp(cb4.ax.axes, 'yticklabels'), color="white")
    ax4.set_title("Top Nodes Influence Map", color="#ef4444", fontsize=13, fontweight="bold", pad=10)
    ax4.tick_params(colors="white")

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    output_file = f"{search_term}_market_heatmaps.png"
    plt.savefig(output_file, dpi=180, facecolor=fig.get_facecolor(), bbox_inches='tight')
    plt.close()
    print(f"[Heatmap] Saved: {output_file}")
    return output_file


def save_heatmap_report(G, analysis, search_term):
    """حفظ بيانات الهيت ماب في ملف تكست مفصل"""
    lines = []
    lines.append("═" * 65)
    lines.append(f"{'MARKET HEATMAP ANALYSIS REPORT':^65}")
    lines.append(f"{'Search: ' + search_term:^65}")
    lines.append("═" * 65)

    # ─── 1. Brand Competition Matrix ───
    comp_matrix, comp_labels = build_brand_competition_matrix(G)
    if comp_matrix is not None and len(comp_labels) > 0:
        lines.append("\n[1] BRAND COMPETITION INTENSITY MATRIX")
        lines.append("-" * 65)
        header = f"{'':15s}" + "".join(f"{b:>12s}" for b in comp_labels)
        lines.append(header)
        for i, brand in enumerate(comp_labels):
            row_vals = "".join(f"{comp_matrix[i][j]:>12.2f}" for j in range(len(comp_labels)))
            lines.append(f"{brand:15s}{row_vals}")
        # Find strongest rivalry
        max_val = comp_matrix.max()
        if max_val > 0:
            idx = np.unravel_index(comp_matrix.argmax(), comp_matrix.shape)
            lines.append(f"\n   Strongest Rivalry: {comp_labels[idx[0]]} vs {comp_labels[idx[1]]} (Score: {max_val:.2f})")

    # ─── 2. Company Centrality ───
    cent_matrix, cent_rows, cent_cols = build_centrality_matrix(G, analysis)
    if cent_matrix is not None and len(cent_rows) > 0:
        lines.append("\n[2] COMPANY CENTRALITY METRICS")
        lines.append("-" * 65)
        header = f"{'Company':20s}" + "".join(f"{c:>14s}" for c in cent_cols)
        lines.append(header)
        for i, comp in enumerate(cent_rows):
            row_vals = "".join(f"{cent_matrix[i][j]:>14.4f}" for j in range(len(cent_cols)))
            lines.append(f"{comp:20s}{row_vals}")
        # Find top per metric
        lines.append("\n   Leaders per metric:")
        for j, metric in enumerate(cent_cols):
            col = cent_matrix[:, j]
            top_idx = col.argmax()
            lines.append(f"   {metric:15s}: {cent_rows[top_idx]} ({col[top_idx]:.4f})")

    # ─── 3. Price Range Density ───
    price_matrix, price_rows, price_cols = build_price_density_matrix(G)
    if price_matrix is not None and len(price_rows) > 0:
        lines.append("\n[3] PRICE RANGE × BRAND DENSITY")
        lines.append("-" * 65)
        header = f"{'Brand':20s}" + "".join(f"{c:>10s}" for c in price_cols) + f"{'Total':>10s}"
        lines.append(header)
        for i, brand in enumerate(price_rows):
            row_vals = "".join(f"{int(price_matrix[i][j]):>10d}" for j in range(len(price_cols)))
            total = int(price_matrix[i].sum())
            lines.append(f"{brand:20s}{row_vals}{total:>10d}")
        # Dominant brand per category
        lines.append("\n   Dominant brand per price range:")
        for j, cat in enumerate(price_cols):
            col = price_matrix[:, j]
            if col.max() > 0:
                top_idx = col.argmax()
                lines.append(f"   {cat:10s}: {price_rows[top_idx]} ({int(col[top_idx])} phones)")

    # ─── 4. Top Nodes Influence ───
    infl_matrix, infl_rows, infl_cols = build_node_influence_matrix(G, analysis)
    if infl_matrix is not None and len(infl_rows) > 0:
        lines.append("\n[4] TOP 15 NODES INFLUENCE MAP")
        lines.append("-" * 65)
        header = f"{'Node':28s}" + "".join(f"{c:>12s}" for c in infl_cols)
        lines.append(header)
        for i, node in enumerate(infl_rows):
            row_vals = "".join(f"{infl_matrix[i][j]:>12.4f}" for j in range(len(infl_cols)))
            lines.append(f"{node:28s}{row_vals}")

    lines.append("\n" + "═" * 65)
    report = "\n".join(lines)

    filename = f"{search_term}_heatmap_report.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(report)
    print(f"[Heatmap] Report saved: {filename}")
    print(report)
    return filename



# ═══════════════════════════════════════════════
#  3D POINT CLOUD — PLOTLY #  mohamed  shalash
# ═══════════════════════════════════════════════
# unique(): لمنع التكرار (هات من كل ماركة نسخة واحدة).
# sorted(): للترتيب الأبجدي عشان النظام.
# tolist(): عشان نحولهم لقائمة سهلة الاستخدام في بايثون.


def build_3d_point_cloud(df: pd.DataFrame, search_term: str) -> str:
    print("\n[Plotly 3D] Building Point Cloud...")
    brands = sorted(df["brand"].unique().tolist())
    sources = sorted(df["source"].unique().tolist())
    brand_map = {b: i for i, b in enumerate(brands)}
    source_map = {s: i for i, s in enumerate(sources)}

    # نفس الألوان اللي فوق
    # #22c55e: أخضر / #3b82f6: أزرق / #f97316: برتقالي
    color_map = {"Low": "#22c55e", "Medium": "#3b82f6", "High": "#f97316"}

    traces = []
    for cat in ["Low", "Medium", "High"]:
        sub = df[df["price_category"] == cat]
        if sub.empty: continue
        traces.append(go.Scatter3d(
            x=sub["price"].tolist(),  # المحور X: السعر المادي
            y=[brand_map[b] for b in sub["brand"]],  # المحور Y: رقم الماركة
            z=[source_map[s] for s in sub["source"]],  # المحور Z: رقم المصدر
            mode="markers",
            name=f"{cat} price",
            # color="white": لون حدود (Stroke) للنقطة البيضا عشان تبرز في الثري دي
            marker=dict(size=6, color=color_map[cat], opacity=0.85, line=dict(width=0.5, color="white")),
            text=[f"<b>{row['name'][:50]}</b><br>Price: {int(row['price'])} EGP<br>Brand: {row['brand']}" for _, row in
                  sub.iterrows()],
            hoverinfo="text",
        ))

    fig = go.Figure(data=traces)
    fig.update_layout(
        # font=dict(color="white"): كل التيكست في الشارت لونه أبيض
        title=dict(text=f"{search_term.capitalize()} Market Map", font=dict(color="white"), x=0.5),

        # #0f172a: لون كحلي غامق لخلفية شارت الثري دي كله
        paper_bgcolor="#0f172a", plot_bgcolor="#0f172a", font=dict(color="white"),

        scene=dict(
            # #334155: لون رصاصي غامق لخطوط الشبكة (Grid) في المحاور
            xaxis=dict(title="Price (EGP)", gridcolor="#334155"),
            yaxis=dict(title="Brand", tickvals=list(brand_map.values()), ticktext=list(brand_map.keys())),
            zaxis=dict(title="Source", tickvals=list(source_map.values()), ticktext=list(source_map.keys())),
        )
    )
    output_file = f"{search_term}_3d_cloud.html"
    fig.write_html(output_file)
    return output_file


# ═══════════════════════════════════════════════
#  FLASK INTEGRATION (FRONTEND) #mohammed  mohammed
# ═══════════════════════════════════════════════

def scrape_and_analyze(search_term: str):
    print(f"\n[API] Starting scrape and analyze for: {search_term}")
    products = scrape_jumia(search_term)
    if not products:
        raise Exception("لم يتم العثور على أي منتجات مطابقة لبحثك.")

    df = process(products, search_term)
    if df.empty:
        raise Exception("حدث خطأ أثناء معالجة البيانات.")

    # Save CSV
    csv_name = f"cleaned_{search_term}.csv"
    df.to_csv(csv_name, index=False, encoding="utf-8-sig")
    print(f"[API] CSV saved successfully: {csv_name}")

    # Build and save Graph
    G, root = build_custom_graph(df, search_term)
    draw_graph(G, root, df, search_term)

    # Build 3D Point Cloud
    html_file = build_3d_point_cloud(df, search_term)
    print(f"[API] 3D Cloud saved: {html_file}")

    # Competitive Market Network Analysis
    comp_G = build_competitive_network(df, search_term)
    comp_analysis = analyze_network(comp_G)
    print_network_report(comp_G, comp_analysis, search_term)
    save_network_report(comp_G, comp_analysis, search_term)
    draw_competitive_network(comp_G, comp_analysis, search_term)

    # Heatmap Analysis
    draw_heatmaps(comp_G, comp_analysis, search_term)
    save_heatmap_report(comp_G, comp_analysis, search_term)
    print("[API] Competitive network + heatmap analysis complete.")

    # Build text file for details
    txt_name = f"{search_term}_market_tree.txt"
    with open(txt_name, 'w', encoding='utf-8') as f:
        f.write(f"تحليل هيكل السوق للمنتج: {search_term}\n")
        f.write("=" * 50 + "\n\n")
        for brand in df["brand"].unique():
            if brand.lower() == "other": continue
            f.write(f" الماركة: {brand}\n")
            bdf = df[df["brand"] == brand]
            for cat in ["Low", "Medium", "High"]:
                cdf = bdf[bdf["price_category"] == cat]
                if not cdf.empty:
                    f.write(f"   ├─ الفئة ({cat}): {len(cdf)} منتج\n")
            f.write("\n")
    print(f"[API] Text summary saved: {txt_name}")


# ═══════════════════════════════════════════════
#  MAIN EXECUTOR # mohammed  shalash
# ═══════════════════════════════════════════════

def main():
    print("====================================================")
    print("   Pro Market Scraper (Amazon & Jumia) - Final")
    print("====================================================")

    search_term = input("\nEnter product to search for (e.g. phone, laptop): ").strip()
    if not search_term: return

    products = scrape_jumia(search_term)
    if not products:
        print("[-] No results found.")
        return

    df = process(products, search_term)
    if df.empty: return

    csv_name = f"{search_term}_cleaned.csv"
    df.to_csv(csv_name, index=False, encoding="utf-8-sig")
    print(f"[File] CSV saved successfully: {csv_name}")

    html_file = build_3d_point_cloud(df, search_term)

    # هنا بنادي على الدوال بتاعتي اللي بترسملي الشجرة
    G, root = build_custom_graph(df, search_term)
    network_file = draw_graph(G, root, df, search_term)

    # ─── Competitive Market Network Analysis ───
    print("\n[Network] Building Competitive Market Network...")
    comp_G = build_competitive_network(df, search_term)
    comp_analysis = analyze_network(comp_G)
    print_network_report(comp_G, comp_analysis, search_term)
    save_network_report(comp_G, comp_analysis, search_term)
    comp_network_file = draw_competitive_network(comp_G, comp_analysis, search_term)

    # ─── Market Heatmaps ───
    print("\n[Heatmap] Building Market Intelligence Heatmaps...")
    heatmap_file = draw_heatmaps(comp_G, comp_analysis, search_term)
    save_heatmap_report(comp_G, comp_analysis, search_term)

    print("\n----------------------------------------------------")
    if (input("Do you want to start Deep Search for accurate prices? (y/n) [y]: ").strip().lower() or "y") == "y":
        pname = input(f"Enter exact model name [{search_term}]: ").strip() or search_term
        brand = input("Enter brand name (optional): ").strip()

        deep_data, query = deep_search(pname, brand)
        save_and_print_deep_results(deep_data, query)

    print("\n----------------------------------------------------")
    if (input("Do you want to open the 3D Graph now? (y/n) [y]: ").strip().lower() or "y") == "y":
        webbrowser.open(os.path.abspath(html_file))

    if (input("Do you want to open your Custom NetworkX Image now? (y/n) [y]: ").strip().lower() or "y") == "y":
        os.system(f'start "" "{network_file}"' if os.name == 'nt' else f'open "{network_file}"')

    if comp_network_file:
        if (input("Do you want to open the Competitive Network Analysis? (y/n) [y]: ").strip().lower() or "y") == "y":
            os.system(f'start "" "{comp_network_file}"' if os.name == 'nt' else f'open "{comp_network_file}"')

    if heatmap_file:
        if (input("Do you want to open the Market Heatmaps? (y/n) [y]: ").strip().lower() or "y") == "y":
            os.system(f'start "" "{heatmap_file}"' if os.name == 'nt' else f'open "{heatmap_file}"')

    print("\n====================================================")
    print("   Task Completed Successfully!")
    print("====================================================")


if __name__ == "__main__":
    main()
#python app.py