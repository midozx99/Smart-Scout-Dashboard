"""
Flask Web Application — Smart Scout Dashboard
يربط كل دوال التحليل من project-12 ويعرضها في واجهة ويب متكاملة
"""
from flask import Flask, render_template, request, send_from_directory
import os
import traceback

# استيراد كل الدوال من project-12
from importlib.machinery import SourceFileLoader
p12 = SourceFileLoader("project12", os.path.join(os.path.dirname(__file__), "project-12.py")).load_module()

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


@app.route("/files/<path:filename>")
def serve_file(filename):
    """تقديم الملفات المولّدة (صور، HTML، CSV، TXT)"""
    return send_from_directory(BASE_DIR, filename)


@app.route("/", methods=["GET", "POST"])
def index():
    ctx = {
        "active_tab": "general",
        "search_term": "",
        "error": None,
        # General analysis
        "image_url": None,
        "csv_url": None,
        "html_3d_url": None,
        "tree_text": None,
        # Competitive Network
        "comp_network_url": None,
        "comp_report_text": None,
        # Heatmaps
        "heatmap_url": None,
        "heatmap_report_text": None,
        # Stats summaries for under each graph
        "stats_3d": None,
        "stats_network": None,
        # All generated files for download
        "generated_files": [],
        # Deep Search
        "deep_search_done": False,
        "deep_data": None,
        "best_deal": None,
        "product_name": "",
        "brand": "",
    }

    if request.method == "POST":
        search_type = request.form.get("search_type", "general")
        ctx["active_tab"] = search_type

        if search_type == "general":
            search_term = request.form.get("search_term", "").strip()
            ctx["search_term"] = search_term
            if not search_term:
                ctx["error"] = "يرجى إدخال اسم المنتج للبحث."
                return render_template("index.html", **ctx)

            try:
                # ─── 1. Scrape Jumia ───
                products = p12.scrape_jumia(search_term)

                # ─── 2. Scrape Amazon ───
                amazon_products = []
                try:
                    amazon_products = p12.scrape_amazon(search_term)
                except Exception as ae:
                    print(f"[Amazon] Scraping failed: {ae}")

                # Combine all products
                all_products = products + amazon_products

                if not all_products:
                    ctx["error"] = "لم يتم العثور على أي منتجات. جرّب كلمة بحث مختلفة."
                    return render_template("index.html", **ctx)

                # ─── 3. Process ───
                df = p12.process(all_products, search_term)
                if df.empty:
                    ctx["error"] = "حدث خطأ أثناء معالجة البيانات."
                    return render_template("index.html", **ctx)

                # ─── 4. Save CSV ───
                csv_name = f"cleaned_{search_term}.csv"
                csv_path = os.path.join(BASE_DIR, csv_name)
                df.to_csv(csv_path, index=False, encoding="utf-8-sig")
                ctx["csv_url"] = f"/files/{csv_name}"
                ctx["generated_files"].append({"name": f"📊 {csv_name}", "url": f"/files/{csv_name}", "type": "CSV"})

                # Build stats summary for 3D section
                jumia_count = len(df[df["source"] == "Jumia"]) if "source" in df.columns else len(df)
                amazon_count = len(df[df["source"] == "Amazon"]) if "source" in df.columns else 0
                low_avg = df[df["price_category"] == "Low"]["price"].mean()
                mid_avg = df[df["price_category"] == "Medium"]["price"].mean()
                high_avg = df[df["price_category"] == "High"]["price"].mean()
                ctx["stats_3d"] = {
                    "total": len(df),
                    "jumia_count": jumia_count,
                    "amazon_count": amazon_count,
                    "brands": len(df["brand"].unique()),
                    "min_price": f"{int(df['price'].min()):,}",
                    "max_price": f"{int(df['price'].max()):,}",
                    "avg_price": f"{int(df['price'].mean()):,}",
                    "low_avg": f"{int(low_avg or 0):,}",
                    "mid_avg": f"{int(mid_avg or 0):,}",
                    "high_avg": f"{int(high_avg or 0):,}",
                }

                # ─── 5. Tree Graph ───
                G, root = p12.build_custom_graph(df, search_term)
                tree_img = p12.draw_graph(G, root, df, search_term)
                ctx["image_url"] = f"/files/{tree_img}"
                ctx["generated_files"].append({"name": f"🌳 {tree_img}", "url": f"/files/{tree_img}", "type": "PNG"})

                # ─── 6. 3D Point Cloud ───
                html_3d = p12.build_3d_point_cloud(df, search_term)
                ctx["html_3d_url"] = f"/files/{html_3d}"
                ctx["generated_files"].append({"name": f"🧊 {html_3d}", "url": f"/files/{html_3d}", "type": "HTML"})

                # ─── 7. Competitive Network ───
                comp_G = p12.build_competitive_network(df, search_term)
                comp_analysis = p12.analyze_network(comp_G)
                comp_net_img = p12.draw_competitive_network(comp_G, comp_analysis, search_term)
                ctx["comp_network_url"] = f"/files/{comp_net_img}" if comp_net_img else None
                if comp_net_img:
                    ctx["generated_files"].append({"name": f"🔗 {comp_net_img}", "url": f"/files/{comp_net_img}", "type": "PNG"})

                comp_report = p12.generate_network_report(comp_G, comp_analysis, search_term)
                report_file = p12.save_network_report(comp_G, comp_analysis, search_term)
                ctx["comp_report_text"] = comp_report
                ctx["generated_files"].append({"name": f"📝 {os.path.basename(report_file)}", "url": f"/files/{os.path.basename(report_file)}", "type": "TXT"})

                # Network stats for under graph
                companies = [n for n, d in comp_G.nodes(data=True) if d.get("type") == "company"]
                phones = [n for n, d in comp_G.nodes(data=True) if d.get("type") == "phone"]
                comp_edges = sum(1 for _, _, d in comp_G.edges(data=True) if d.get("type") == "competition")
                mic = comp_analysis.get("most_influential_company", "N/A")
                ctx["stats_network"] = {
                    "nodes": comp_G.number_of_nodes(),
                    "edges": comp_G.number_of_edges(),
                    "companies": len(companies),
                    "phones": len(phones),
                    "competition_edges": comp_edges,
                    "top_company": mic,
                    "communities": len(comp_analysis.get("communities", [])),
                }

                # ─── 8. Heatmaps ───
                heatmap_img = p12.draw_heatmaps(comp_G, comp_analysis, search_term)
                ctx["heatmap_url"] = f"/files/{heatmap_img}" if heatmap_img else None
                if heatmap_img:
                    ctx["generated_files"].append({"name": f"🔥 {heatmap_img}", "url": f"/files/{heatmap_img}", "type": "PNG"})

                heatmap_report_file = p12.save_heatmap_report(comp_G, comp_analysis, search_term)
                heatmap_path = os.path.join(BASE_DIR, f"{search_term}_heatmap_report.txt")
                if os.path.exists(heatmap_path):
                    with open(heatmap_path, "r", encoding="utf-8") as f:
                        ctx["heatmap_report_text"] = f.read()
                ctx["generated_files"].append({"name": f"📝 {os.path.basename(heatmap_report_file)}", "url": f"/files/{os.path.basename(heatmap_report_file)}", "type": "TXT"})

                # ─── 9. Tree text summary ───
                txt_name = f"{search_term}_market_tree.txt"
                txt_path = os.path.join(BASE_DIR, txt_name)
                with open(txt_path, "w", encoding="utf-8") as f:
                    f.write(f"تحليل هيكل السوق للمنتج: {search_term}\n")
                    f.write("=" * 50 + "\n\n")
                    for brand_name in df["brand"].unique():
                        if brand_name.lower() == "other":
                            continue
                        f.write(f" الماركة: {brand_name}\n")
                        bdf = df[df["brand"] == brand_name]
                        for cat in ["Low", "Medium", "High"]:
                            cdf = bdf[bdf["price_category"] == cat]
                            if not cdf.empty:
                                f.write(f"   ├─ الفئة ({cat}): {len(cdf)} منتج\n")
                        f.write("\n")
                with open(txt_path, "r", encoding="utf-8") as f:
                    ctx["tree_text"] = f.read()
                ctx["generated_files"].append({"name": f"📝 {txt_name}", "url": f"/files/{txt_name}", "type": "TXT"})

            except Exception as e:
                traceback.print_exc()
                ctx["error"] = f"حدث خطأ: {str(e)}"

        elif search_type == "deep":
            product_name = request.form.get("product_name", "").strip()
            brand = request.form.get("brand", "").strip()
            ctx["product_name"] = product_name
            ctx["brand"] = brand

            if not product_name:
                ctx["error"] = "يرجى إدخال اسم الموديل للبحث العميق."
                return render_template("index.html", **ctx)

            try:
                deep_data, query = p12.deep_search(product_name, brand)
                p12.save_and_print_deep_results(deep_data, query)
                ctx["deep_search_done"] = True

                class Item:
                    def __init__(self, d):
                        self.name = d.get("name", "")
                        self.price = d.get("price", 0)
                        self.link = d.get("link", "")
                        self.source = d.get("source", "")

                class DeepData:
                    def __init__(self, data):
                        self.amazon = [Item(i) for i in data.get("amazon", [])]
                        self.jumia = [Item(i) for i in data.get("jumia", [])]

                ctx["deep_data"] = DeepData(deep_data)

                # Find best deal
                all_items = []
                for src_key, src_name in [("amazon", "Amazon"), ("jumia", "Jumia")]:
                    for item in deep_data.get(src_key, []):
                        if item.get("price"):
                            all_items.append({
                                "name": item["name"],
                                "price": item["price"],
                                "link": item.get("link", ""),
                                "store": src_name
                            })
                if all_items:
                    best = min(all_items, key=lambda x: x["price"])
                    class BestDeal:
                        def __init__(self, d):
                            self.name = d["name"]
                            self.price = d["price"]
                            self.link = d["link"]
                            self.store = d["store"]
                    ctx["best_deal"] = BestDeal(best)

                # Add deep search report file
                report_name = f"{query.replace(' ', '_')}_Market_Report.txt"
                if os.path.exists(os.path.join(BASE_DIR, report_name)):
                    ctx["generated_files"].append({"name": f"📝 {report_name}", "url": f"/files/{report_name}", "type": "TXT"})

            except Exception as e:
                traceback.print_exc()
                ctx["error"] = f"حدث خطأ في البحث العميق: {str(e)}"

    return render_template("index.html", **ctx)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
